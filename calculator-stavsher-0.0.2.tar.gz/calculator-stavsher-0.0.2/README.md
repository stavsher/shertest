# Simple Calculator Package

This is a simple calculator package.  
It supports addition and subtraction.  